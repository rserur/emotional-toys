// simpleDecompose.h

typedef short numtype;

void simpleDecompose(numtype *data, int rows, int cols);
